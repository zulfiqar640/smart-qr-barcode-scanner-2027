/* Minimal QR Code encoder (byte mode, error correction level M, versions 1-40).
   Based on the public algorithm described in ISO/IEC 18004. */
(function (global) {
  "use strict";
  var ECC_TABLES = {
    L: { e: [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
         n: [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25], f: 1 },
    M: { e: [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
         n: [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49], f: 0 },
    Q: { e: [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
         n: [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68], f: 3 },
    H: { e: [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
         n: [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81], f: 2 }
  };
  var ECC_PER_BLOCK = ECC_TABLES.M.e, NUM_BLOCKS = ECC_TABLES.M.n, ECC_FORMAT = 0;
  function useEcc(level) { var t = ECC_TABLES[level] || ECC_TABLES.M; ECC_PER_BLOCK = t.e; NUM_BLOCKS = t.n; ECC_FORMAT = t.f; }

  function appendBits(arr, val, len) { for (var i = len - 1; i >= 0; i--) arr.push((val >>> i) & 1); }
  function rawModules(ver) {
    var r = (16 * ver + 128) * ver + 64;
    if (ver >= 2) { var a = Math.floor(ver / 7) + 2; r -= (25 * a - 10) * a - 55; if (ver >= 7) r -= 36; }
    return r;
  }
  function dataCodewords(ver) { return Math.floor(rawModules(ver) / 8) - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver]; }
  function gfMul(x, y) { var z = 0; for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z; }
  function rsDivisor(deg) {
    var r = []; for (var i = 0; i < deg; i++) r.push(0); r[deg - 1] = 1;
    var root = 1;
    for (i = 0; i < deg; i++) {
      for (var j = 0; j < r.length; j++) { r[j] = gfMul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; }
      root = gfMul(root, 2);
    }
    return r;
  }
  function rsRemainder(data, div) {
    var r = div.map(function () { return 0; });
    data.forEach(function (b) {
      var f = b ^ r.shift(); r.push(0);
      div.forEach(function (c, i) { r[i] ^= gfMul(c, f); });
    });
    return r;
  }
  function interleave(data, ver) {
    var nb = NUM_BLOCKS[ver], bel = ECC_PER_BLOCK[ver], raw = Math.floor(rawModules(ver) / 8);
    var numShort = nb - raw % nb, shortLen = Math.floor(raw / nb), blocks = [], div = rsDivisor(bel);
    for (var i = 0, k = 0; i < nb; i++) {
      var dat = data.slice(k, k + shortLen - bel + (i < numShort ? 0 : 1)); k += dat.length;
      var ecc = rsRemainder(dat, div); if (i < numShort) dat.push(0);
      blocks.push(dat.concat(ecc));
    }
    var out = [];
    for (i = 0; i < blocks[0].length; i++) blocks.forEach(function (b, j) { if (i !== shortLen - bel || j >= numShort) out.push(b[i]); });
    return out;
  }
  function alignPositions(ver) {
    if (ver === 1) return [];
    var n = Math.floor(ver / 7) + 2, step = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2, r = [6];
    for (var pos = ver * 4 + 10; r.length < n; pos -= step) r.splice(1, 0, pos);
    return r;
  }
  var MASKS = [
    function (x, y) { return (x + y) % 2 === 0; },
    function (x, y) { return y % 2 === 0; },
    function (x, y) { return x % 3 === 0; },
    function (x, y) { return (x + y) % 3 === 0; },
    function (x, y) { return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; },
    function (x, y) { return x * y % 2 + x * y % 3 === 0; },
    function (x, y) { return (x * y % 2 + x * y % 3) % 2 === 0; },
    function (x, y) { return ((x + y) % 2 + x * y % 3) % 2 === 0; }
  ];

  function encode(text, ecl) {
    ecl = ECC_TABLES[ecl] ? ecl : "M"; useEcc(ecl);
    var bytes = Array.prototype.slice.call(new TextEncoder().encode(text));
    var ver, cap;
    for (ver = 1; ver <= 40; ver++) {
      cap = dataCodewords(ver) * 8;
      if (4 + (ver < 10 ? 8 : 16) + bytes.length * 8 <= cap) break;
    }
    if (ver > 40) throw new Error("Text too long");
    var bits = [];
    appendBits(bits, 4, 4); appendBits(bits, bytes.length, ver < 10 ? 8 : 16);
    bytes.forEach(function (b) { appendBits(bits, b, 8); });
    appendBits(bits, 0, Math.min(4, cap - bits.length));
    appendBits(bits, 0, (8 - bits.length % 8) % 8);
    for (var pad = 0xEC; bits.length < cap; pad ^= 0xEC ^ 0x11) appendBits(bits, pad, 8);
    var data = [];
    for (var i = 0; i < bits.length; i += 8) { var v = 0; for (var j = 0; j < 8; j++) v = (v << 1) | bits[i + j]; data.push(v); }
    var all = interleave(data, ver);

    var size = ver * 4 + 17, m = [], fn = [];
    for (var y = 0; y < size; y++) { m.push(new Array(size).fill(false)); fn.push(new Array(size).fill(false)); }
    function setFn(x, y, d) { m[y][x] = d; fn[y][x] = true; }
    function finder(cx, cy) {
      for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
        var d = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy;
        if (xx >= 0 && xx < size && yy >= 0 && yy < size) setFn(xx, yy, d !== 2 && d !== 4);
      }
    }
    for (i = 0; i < size; i++) { setFn(6, i, i % 2 === 0); setFn(i, 6, i % 2 === 0); }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var ap = alignPositions(ver), n = ap.length;
    for (i = 0; i < n; i++) for (j = 0; j < n; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0)) continue;
      for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) setFn(ap[i] + dx, ap[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
    function formatBits(mask) {
      var d = (ECC_FORMAT << 3) | mask, rem = d; // 2 ECC bits + 3 mask bits
      for (var i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      var b = ((d << 10) | rem) ^ 0x5412;
      function bit(i) { return ((b >>> i) & 1) !== 0; }
      for (i = 0; i <= 5; i++) setFn(8, i, bit(i));
      setFn(8, 7, bit(6)); setFn(8, 8, bit(7)); setFn(7, 8, bit(8));
      for (i = 9; i < 15; i++) setFn(14 - i, 8, bit(i));
      for (i = 0; i < 8; i++) setFn(size - 1 - i, 8, bit(i));
      for (i = 8; i < 15; i++) setFn(8, size - 15 + i, bit(i));
      setFn(8, size - 8, true);
    }
    formatBits(0);
    if (ver >= 7) {
      var rem = ver;
      for (i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
      var vb = (ver << 12) | rem;
      for (i = 0; i < 18; i++) { var bt = ((vb >>> i) & 1) !== 0, a = size - 11 + i % 3, b2 = Math.floor(i / 3); setFn(a, b2, bt); setFn(b2, a, bt); }
    }
    // data placement
    var k2 = 0;
    for (var right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < size; vert++) for (j = 0; j < 2; j++) {
        var x = right - j, up = ((right + 1) & 2) === 0, yy2 = up ? size - 1 - vert : vert;
        if (!fn[yy2][x] && k2 < all.length * 8) { m[yy2][x] = ((all[k2 >>> 3] >>> (7 - (k2 & 7))) & 1) !== 0; k2++; }
      }
    }
    function applyMask(mask) { for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) if (!fn[y][x] && MASKS[mask](x, y)) m[y][x] = !m[y][x]; }
    function penalty() {
      var p = 0, x, y, run, i;
      for (y = 0; y < size; y++) { run = 1; for (x = 1; x < size; x++) { if (m[y][x] === m[y][x - 1]) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
      for (x = 0; x < size; x++) { run = 1; for (y = 1; y < size; y++) { if (m[y][x] === m[y - 1][x]) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
      for (y = 0; y < size - 1; y++) for (x = 0; x < size - 1; x++) if (m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
      var dark = 0; for (y = 0; y < size; y++) for (x = 0; x < size; x++) if (m[y][x]) dark++;
      p += Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10;
      return p;
    }
    var best = 0, bestP = Infinity;
    for (var mk = 0; mk < 8; mk++) {
      applyMask(mk); formatBits(mk);
      var pn = penalty(); if (pn < bestP) { bestP = pn; best = mk; }
      applyMask(mk);
    }
    applyMask(best); formatBits(best);
    return { size: size, version: ver, ecl: ecl, get: function (x, y) { return m[y][x]; } };
  }

  /** Builds one SVG path string (module units) for the foreground. style: square | rounded | dots */
  function buildPath(q, style) {
    var d = "", n = q.size, x, y, r;
    function rr(x, y, w, h, r) { return "M" + (x + r) + " " + y + "h" + (w - 2 * r) + "a" + r + " " + r + " 0 0 1 " + r + " " + r + "v" + (h - 2 * r) + "a" + r + " " + r + " 0 0 1 -" + r + " " + r + "h-" + (w - 2 * r) + "a" + r + " " + r + " 0 0 1 -" + r + " -" + r + "v-" + (h - 2 * r) + "a" + r + " " + r + " 0 0 1 " + r + " -" + r + "z"; }
    var fancy = style === "rounded" || style === "dots";
    function inFinder(x, y) { return (x < 7 && y < 7) || (x >= n - 7 && y < 7) || (x < 7 && y >= n - 7); }
    for (y = 0; y < n; y++) for (x = 0; x < n; x++) {
      if (!q.get(x, y) || (fancy && inFinder(x, y))) continue;
      if (style === "dots") { r = 0.5; d += "M" + (x + 0.5 - r) + " " + (y + 0.5) + "a" + r + " " + r + " 0 1 0 " + 2 * r + " 0a" + r + " " + r + " 0 1 0 -" + 2 * r + " 0z"; }
      else if (style === "rounded") d += rr(x, y, 1, 1, 0.22);
      else d += "M" + x + " " + y + "h1v1h-1z";
    }
    /* finder patterns keep their exact 1:1:3:1:1 geometry (only the outer corners are softened) so every scanner can lock on */
    if (fancy) [[0, 0], [n - 7, 0], [0, n - 7]].forEach(function (p) {
      d += rr(p[0], p[1], 7, 7, 1.2) + "M" + (p[0] + 1) + " " + (p[1] + 1) + "h5v5h-5z" + rr(p[0] + 2, p[1] + 2, 3, 3, 0.6);
    });
    return d;
  }
  function norm(o) {
    o = o || {};
    return { fg: o.fg || "#000000", fg2: o.fg2 || null, bg: o.bg === null || o.bg === "transparent" ? null : (o.bg || "#ffffff"), ecl: o.ecl || "M", quiet: o.quiet == null ? 3 : o.quiet, style: o.style || "square" };
  }
  /** Draws a QR for `text` onto a canvas (with quiet zone). Returns the canvas.
      Backwards compatible: toCanvas(text, px) renders black on white like before. */
  function toCanvas(text, px, opts) {
    var o = norm(opts), q = encode(text, o.ecl), total = q.size + o.quiet * 2, scale = Math.max(1, Math.floor((px || 512) / total));
    var c = document.createElement("canvas"); c.width = c.height = total * scale;
    var g = c.getContext("2d");
    if (o.bg) { g.fillStyle = o.bg; g.fillRect(0, 0, c.width, c.height); }
    var fill = o.fg;
    if (o.fg2) { var gr = g.createLinearGradient(0, 0, c.width, c.height); gr.addColorStop(0, o.fg); gr.addColorStop(1, o.fg2); fill = gr; }
    g.fillStyle = fill;
    if (o.style === "square" && !o.fg2) {
      for (var y = 0; y < q.size; y++) for (var x = 0; x < q.size; x++) if (q.get(x, y)) g.fillRect((x + o.quiet) * scale, (y + o.quiet) * scale, scale, scale);
    } else {
      g.save(); g.translate(o.quiet * scale, o.quiet * scale); g.scale(scale, scale);
      g.fill(new Path2D(buildPath(q, o.style)), "evenodd"); g.restore();
    }
    c.qrInfo = { version: q.version, modules: q.size, scale: scale, ecl: o.ecl };
    return c;
  }
  /** Returns an SVG string (vector, resolution independent). */
  function toSVG(text, opts) {
    var o = norm(opts), q = encode(text, o.ecl), total = q.size + o.quiet * 2;
    var defs = o.fg2 ? '<defs><linearGradient id="g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="' + total + '" y2="' + total + '"><stop offset="0" stop-color="' + o.fg + '"/><stop offset="1" stop-color="' + o.fg2 + '"/></linearGradient></defs>' : "";
    return '<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + total + " " + total + '" width="1024" height="1024" shape-rendering="' + (o.style === "square" ? "crispEdges" : "geometricPrecision") + '">' + defs +
      (o.bg ? '<rect width="100%" height="100%" fill="' + o.bg + '"/>' : "") +
      '<path transform="translate(' + o.quiet + " " + o.quiet + ')" fill="' + (o.fg2 ? "url(#g)" : o.fg) + '" fill-rule="evenodd" d="' + buildPath(q, o.style) + '"/></svg>';
  }
  global.QR = { encode: encode, toCanvas: toCanvas, toSVG: toSVG };
})(typeof window !== "undefined" ? window : globalThis);
