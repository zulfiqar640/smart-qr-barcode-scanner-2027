package com.smartqr.barcodescanner2027;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

/**
 * Hosts the QR Smart Scanner web app (bundled in assets/www) inside a WebView.
 * The app is served from https://appassets.androidplatform.net (a secure origin, so the camera works),
 * and never needs the INTERNET permission.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";
    private static final List<String> EXTERNAL_SCHEMES =
            Arrays.asList("http", "https", "tel", "sms", "smsto", "mailto", "geo");

    private static final int RC_CAMERA = 10;
    private static final int RC_FILE = 11;
    private static final int RC_LOCATION = 12;

    private WebView web;
    private WebViewAssetLoader assetLoader;
    private BarcodeScanner scanner;

    private PermissionRequest pendingWebPermission;
    private ValueCallback<Uri[]> fileCallback;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;

    // ---- Ads (Google AdMob) ----
    private static final String TEST_BANNER = "ca-app-pub-3940256099942544/9214589741";
    private static final String TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_APP_OPEN = "ca-app-pub-3940256099942544/9257395921";
    private static final int LEAVES_PER_AD = 2;            // one full-screen ad after every 2nd result (Google's maximum rate)
    private static final long AD_SPACING_MS = 30_000L;     // never two full-screen ads back to back
    private static final long APP_OPEN_GAP_MS = 120_000L;  // App Open ad at most once every 2 minutes
    private static final long APP_OPEN_WINDOW_MS = 5_000L; // only right after the app comes to the front
    private static final long APP_OPEN_MAX_AGE_MS = 3L * 3600_000L; // App Open ads expire after 4 h
    private FrameLayout bannerBox;
    private AdView bannerView;
    private InterstitialAd interstitial;
    private boolean adsReady, bannerLoaded, bannerWanted, imeVisible, interstitialLoading;
    private int leaves;
    private AppOpenAd appOpenAd;
    private boolean appOpenLoading, fullScreenAdShowing, skipNextAppOpen, wasStopped, hasShownAppOpen, wantAppOpen;
    private long lastFullScreenAdAt, lastAppOpenAt, appOpenLoadedAt, foregroundAt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#060F34"));
        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        bannerBox = new FrameLayout(this);
        bannerBox.setVisibility(View.GONE);
        root.addView(bannerBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        // Android 15 draws edge-to-edge: keep the web content clear of the system bars and keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            imeVisible = insets.isVisible(WindowInsetsCompat.Type.ime());
            applyBanner();
            return WindowInsetsCompat.CONSUMED;
        });

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        scanner = BarcodeScanning.getClient();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setGeolocationEnabled(true);

        web.setBackgroundColor(Color.parseColor("#060F34"));
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) {
                    return false; // our own pages stay in the app
                }
                route(u);
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsVideo = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            wantsVideo = true;
                        }
                    }
                    if (!wantsVideo) {
                        request.deny();
                        return;
                    }
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        if (pendingWebPermission != null) {
                            pendingWebPermission.deny();
                        }
                        pendingWebPermission = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, RC_CAMERA);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    skipNextAppOpen = true;
                    startActivityForResult(params.createIntent(), RC_FILE);
                } catch (Exception e) {
                    skipNextAppOpen = false;
                    fileCallback = null;
                    toast("No gallery or file app found");
                    return false;
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    geoOrigin = origin;
                    geoCallback = callback;
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, RC_LOCATION);
                }
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });

        leaves = getSharedPreferences("ads", MODE_PRIVATE).getInt("leaves", 0);
        initAds();

        web.loadUrl(START_URL);
    }

    // ------------------------------------------------------------------------------------------
    // Ads. Banner only on non-camera screens; full-screen ad only after leaving a result screen.
    // ------------------------------------------------------------------------------------------
    private boolean useTestAds() {
        return getResources().getBoolean(R.bool.ads_use_test);
    }

    private String bannerId() {
        return useTestAds() ? TEST_BANNER : getString(R.string.admob_banner_id);
    }

    private String interstitialId() {
        return useTestAds() ? TEST_INTERSTITIAL : getString(R.string.admob_interstitial_id);
    }

    private void initAds() {
        new Thread(() -> {
            try {
                MobileAds.initialize(MainActivity.this, status -> runOnUiThread(this::onAdsReady));
            } catch (Throwable ignored) {
                // ads are optional: the scanner must keep working without them
            }
        }).start();
    }

    private void onAdsReady() {
        if (isFinishing() || adsReady) {
            return;
        }
        adsReady = true;
        try {
            bannerView = new AdView(this);
            bannerView.setAdUnitId(bannerId());
            int widthDp = (int) (getResources().getDisplayMetrics().widthPixels
                    / getResources().getDisplayMetrics().density);
            bannerView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, widthDp));
            bannerView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    bannerLoaded = true;
                    applyBanner();
                }

                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    bannerLoaded = false;
                    applyBanner();
                }
            });
            bannerBox.addView(bannerView);
            bannerView.loadAd(new AdRequest.Builder().build());
        } catch (Throwable ignored) {
            bannerView = null;
        }
        loadInterstitial();
        loadAppOpen();
    }

    /** Banner shows only when a non-camera screen is open, an ad has loaded and the keyboard is closed. */
    private void applyBanner() {
        if (bannerBox == null) {
            return;
        }
        boolean show = adsReady && bannerLoaded && bannerWanted && !imeVisible;
        bannerBox.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void loadInterstitial() {
        if (!adsReady || interstitial != null || interstitialLoading) {
            return;
        }
        interstitialLoading = true;
        try {
            InterstitialAd.load(this, interstitialId(), new AdRequest.Builder().build(),
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(InterstitialAd ad) {
                            interstitialLoading = false;
                            interstitial = ad;
                            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override
                                public void onAdShowedFullScreenContent() {
                                    fullScreenAdShowing = true;
                                    lastFullScreenAdAt = SystemClock.elapsedRealtime();
                                }

                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    interstitial = null;
                                    fullScreenAdShowing = false;
                                    lastFullScreenAdAt = SystemClock.elapsedRealtime();
                                    loadInterstitial();
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(AdError error) {
                                    interstitial = null;
                                    fullScreenAdShowing = false;
                                    loadInterstitial();
                                }
                            });
                        }

                        @Override
                        public void onAdFailedToLoad(LoadAdError error) {
                            interstitialLoading = false;
                            interstitial = null;
                        }
                    });
        } catch (Throwable t) {
            interstitialLoading = false;
        }
    }

    /** Called when the user leaves a result screen (a natural break, never while scanning).
        The counter is saved, so users who scan once per visit still get an ad on every 2nd scan overall. */
    private void onLeftResult() {
        leaves++;
        getSharedPreferences("ads", MODE_PRIVATE).edit().putInt("leaves", leaves).apply();
        if (leaves < LEAVES_PER_AD) {
            return;
        }
        if (interstitial == null) {
            loadInterstitial();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (fullScreenAdShowing || (lastFullScreenAdAt != 0 && now - lastFullScreenAdAt < AD_SPACING_MS)) {
            return;
        }
        leaves = 0;
        getSharedPreferences("ads", MODE_PRIVATE).edit().putInt("leaves", 0).apply();
        try {
            interstitial.show(this);
        } catch (Throwable t) {
            interstitial = null;
        }
    }

    // ---- App Open ad: shown when the app is opened or brought back to the front (never on exit) ----
    private String appOpenId() {
        return useTestAds() ? TEST_APP_OPEN : getString(R.string.admob_appopen_id);
    }

    private void loadAppOpen() {
        if (!adsReady || appOpenAd != null || appOpenLoading) {
            return;
        }
        String id = appOpenId();
        if (id == null || id.trim().isEmpty()) {
            return;
        }
        appOpenLoading = true;
        try {
            AppOpenAd.load(this, id, new AdRequest.Builder().build(), new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(AppOpenAd ad) {
                    appOpenLoading = false;
                    appOpenAd = ad;
                    appOpenLoadedAt = SystemClock.elapsedRealtime();
                    maybeShowAppOpen();
                }

                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    appOpenLoading = false;
                    appOpenAd = null;
                }
            });
        } catch (Throwable t) {
            appOpenLoading = false;
        }
    }

    private void maybeShowAppOpen() {
        if (!wantAppOpen || !adsReady || appOpenAd == null || fullScreenAdShowing || isFinishing()) {
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - foregroundAt > APP_OPEN_WINDOW_MS) {
            wantAppOpen = false;
            return;
        }
        if (now - appOpenLoadedAt > APP_OPEN_MAX_AGE_MS) {
            appOpenAd = null;
            loadAppOpen();
            return;
        }
        if (hasShownAppOpen && now - lastAppOpenAt < APP_OPEN_GAP_MS) {
            wantAppOpen = false;
            return;
        }
        final AppOpenAd ad = appOpenAd;
        appOpenAd = null;
        wantAppOpen = false;
        hasShownAppOpen = true;
        lastAppOpenAt = now;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdShowedFullScreenContent() {
                fullScreenAdShowing = true;
                lastFullScreenAdAt = SystemClock.elapsedRealtime();
            }

            @Override
            public void onAdDismissedFullScreenContent() {
                fullScreenAdShowing = false;
                lastFullScreenAdAt = SystemClock.elapsedRealtime();
                loadAppOpen();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError error) {
                fullScreenAdShowing = false;
                loadAppOpen();
            }
        });
        try {
            ad.show(this);
        } catch (Throwable t) {
            fullScreenAdShowing = false;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        wasStopped = false;
        long now = SystemClock.elapsedRealtime();
        if (skipNextAppOpen) {           // back from gallery / share sheet / a link: the user never really left
            skipNextAppOpen = false;
            return;
        }
        if (fullScreenAdShowing || (lastFullScreenAdAt != 0 && now - lastFullScreenAdAt < 3000)) {
            return;                       // coming back from one of our own ads
        }
        wantAppOpen = true;
        foregroundAt = now;
        maybeShowAppOpen();
    }

    @Override
    protected void onStop() {
        super.onStop();
        wasStopped = true;
    }

    /** Opens a link: our own pages inside the app, everything else in the matching Android app. */
    private void route(Uri u) {
        if (u == null) {
            return;
        }
        if (HOST.equals(u.getHost())) {
            web.loadUrl(u.toString());
            return;
        }
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        if (!EXTERNAL_SCHEMES.contains(scheme)) {
            return; // ignore javascript:, intent:, file:, blob: ...
        }
        try {
            skipNextAppOpen = true;
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) {
            skipNextAppOpen = false;
            toast("No app can open this link");
        }
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == RC_CAMERA && pendingWebPermission != null) {
            if (granted) {
                pendingWebPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                pendingWebPermission.deny();
            }
            pendingWebPermission = null;
        } else if (requestCode == RC_LOCATION && geoCallback != null) {
            boolean any = false;
            for (int g : grantResults) {
                if (g == PackageManager.PERMISSION_GRANTED) {
                    any = true;
                }
            }
            geoCallback.invoke(geoOrigin, any, false);
            geoCallback = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (bannerView != null) {
            bannerView.pause();
        }
        if (web != null) {
            web.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bannerView != null) {
            bannerView.resume();
        }
        if (web != null) {
            web.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (bannerView != null) {
            bannerView.destroy();
            bannerView = null;
        }
        if (scanner != null) {
            scanner.close();
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------------------------------
    // JavaScript bridge (window.AndroidBridge). Only our own bundled pages are ever loaded here.
    // ------------------------------------------------------------------------------------------
    private class Bridge {

        @JavascriptInterface
        public void detect(final int id, String base64Jpeg) {
            try {
                byte[] bytes = Base64.decode(base64Jpeg, Base64.DEFAULT);
                final Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bmp == null) {
                    deliver(id, "[]");
                    return;
                }
                scanner.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener(list -> deliver(id, toJson(list)))
                        .addOnFailureListener(e -> deliver(id, "[]"));
            } catch (Exception e) {
                deliver(id, "[]");
            }
        }

        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String where;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) {
                        throw new Exception("insert failed");
                    }
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        out.write(data);
                    }
                    where = "Downloads";
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    File f = new File(dir, name);
                    try (OutputStream out = new FileOutputStream(f)) {
                        out.write(data);
                    }
                    where = f.getAbsolutePath();
                }
                toast("Saved to " + where + ": " + name);
            } catch (Exception e) {
                toast("Could not save the file");
            }
        }

        @JavascriptInterface
        public void shareFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new Exception("mkdir failed");
                }
                final File f = new File(dir, name);
                try (OutputStream out = new FileOutputStream(f)) {
                    out.write(data);
                }
                final String type = mime;
                runOnUiThread(() -> {
                    Uri uri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".fileprovider", f);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType(type);
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    skipNextAppOpen = true;
                    startActivity(Intent.createChooser(i, "Share"));
                });
            } catch (Exception e) {
                toast("Could not share the file");
            }
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                skipNextAppOpen = true;
                startActivity(Intent.createChooser(i, "Share"));
            });
        }

        @JavascriptInterface
        public void shareApp() {
            share("Smart QR Scanner - fast, private QR & barcode scanner and creator: "
                    + "https://play.google.com/store/apps/details?id=" + getPackageName());
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("QR", text));
                }
            });
        }

        @JavascriptInterface
        public void openExternal(final String url) {
            runOnUiThread(() -> route(Uri.parse(url)));
        }

        @JavascriptInterface
        public void adScreen(final String view) {
            runOnUiThread(() -> {
                bannerWanted = view != null && !"scan".equals(view) && !"batch".equals(view);
                applyBanner();
            });
        }

        @JavascriptInterface
        public void adLeave() {
            runOnUiThread(MainActivity.this::onLeftResult);
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                skipNextAppOpen = true;
                startActivity(i);
            });
        }
    }

    private void deliver(final int id, final String json) {
        final String js = "window.__mlResult(" + id + "," + JSONObject.quote(json) + ")";
        runOnUiThread(() -> {
            if (web != null) {
                web.evaluateJavascript(js, null);
            }
        });
    }

    private static String formatName(int f) {
        switch (f) {
            case Barcode.FORMAT_QR_CODE: return "qr_code";
            case Barcode.FORMAT_AZTEC: return "aztec";
            case Barcode.FORMAT_CODABAR: return "codabar";
            case Barcode.FORMAT_CODE_39: return "code_39";
            case Barcode.FORMAT_CODE_93: return "code_93";
            case Barcode.FORMAT_CODE_128: return "code_128";
            case Barcode.FORMAT_DATA_MATRIX: return "data_matrix";
            case Barcode.FORMAT_EAN_8: return "ean_8";
            case Barcode.FORMAT_EAN_13: return "ean_13";
            case Barcode.FORMAT_ITF: return "itf";
            case Barcode.FORMAT_PDF417: return "pdf417";
            case Barcode.FORMAT_UPC_A: return "upc_a";
            case Barcode.FORMAT_UPC_E: return "upc_e";
            default: return "unknown";
        }
    }

    private static String toJson(List<Barcode> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Barcode b : list) {
                String raw = b.getRawValue();
                if (raw == null) {
                    raw = b.getDisplayValue();
                }
                if (raw == null || raw.trim().isEmpty()) {
                    continue;
                }
                JSONObject o = new JSONObject();
                o.put("rawValue", raw);
                o.put("format", formatName(b.getFormat()));
                Rect r = b.getBoundingBox();
                if (r != null) {
                    JSONObject bb = new JSONObject();
                    bb.put("x", r.left);
                    bb.put("y", r.top);
                    bb.put("width", r.width());
                    bb.put("height", r.height());
                    o.put("boundingBox", bb);
                }
                Point[] pts = b.getCornerPoints();
                if (pts != null) {
                    JSONArray pa = new JSONArray();
                    for (Point p : pts) {
                        JSONObject po = new JSONObject();
                        po.put("x", p.x);
                        po.put("y", p.y);
                        pa.put(po);
                    }
                    o.put("cornerPoints", pa);
                }
                arr.put(o);
            }
        } catch (Exception ignored) {
            // return what we have
        }
        return arr.toString();
    }
}
