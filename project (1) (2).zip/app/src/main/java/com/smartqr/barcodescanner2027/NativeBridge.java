package com.smartqr.barcodescanner2027;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Functions the web app can call: barcode decoding (ML Kit, on device) and saving files to Downloads. */
public class NativeBridge {
    private final Context context;
    private final BarcodeScanner scanner = BarcodeScanning.getClient();

    public NativeBridge(Context context) { this.context = context.getApplicationContext(); }

    private static String formatName(int f) {
        switch (f) {
            case Barcode.FORMAT_QR_CODE: return "qr_code";
            case Barcode.FORMAT_AZTEC: return "aztec";
            case Barcode.FORMAT_CODABAR: return "codabar";
            case Barcode.FORMAT_CODE_39: return "code_39";
            case Barcode.FORMAT_CODE_93: return "code_93";
            case Barcode.FORMAT_CODE_128: return "code_128";
            case Barcode.FORMAT_DATA_MATRIX: return "data_matrix";
            case Barcode.FORMAT_EAN_8: return "ean_8";
            case Barcode.FORMAT_EAN_13: return "ean_13";
            case Barcode.FORMAT_ITF: return "itf";
            case Barcode.FORMAT_PDF417: return "pdf417";
            case Barcode.FORMAT_UPC_A: return "upc_a";
            case Barcode.FORMAT_UPC_E: return "upc_e";
            default: return "unknown";
        }
    }

    /** Called from JavaScript (background thread). Input: base64 JPEG. Output: JSON array of codes. */
    @JavascriptInterface
    public String decode(String base64Jpeg) {
        JSONArray out = new JSONArray();
        try {
            byte[] bytes = Base64.decode(base64Jpeg, Base64.DEFAULT);
            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bmp == null) return out.toString();
            List<Barcode> codes = Tasks.await(scanner.process(InputImage.fromBitmap(bmp, 0)), 8, TimeUnit.SECONDS);
            for (Barcode b : codes) {
                String raw = b.getRawValue();
                if (raw == null) continue;
                JSONObject o = new JSONObject();
                o.put("rawValue", raw);
                o.put("format", formatName(b.getFormat()));
                Rect r = b.getBoundingBox();
                o.put("x", r != null ? r.left : 0);
                o.put("y", r != null ? r.top : 0);
                o.put("width", r != null ? r.width() : bmp.getWidth());
                o.put("height", r != null ? r.height() : bmp.getHeight());
                out.put(o);
            }
            bmp.recycle();
        } catch (Exception ignored) { }
        return out.toString();
    }

    /** Saves a file into the phone's Downloads folder. Returns true on success. */
    @JavascriptInterface
    public boolean saveFile(String name, String mime, String base64Data) {
        try {
            String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
            byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
            ContentResolver cr = context.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
            v.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime.split(";")[0]);
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return false;
            try (OutputStream os = cr.openOutputStream(uri)) {
                if (os == null) return false;
                os.write(data);
            }
            return true;
        } catch (Exception e) { return false; }
    }
}
