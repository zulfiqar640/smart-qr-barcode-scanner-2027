# Smart QR & Barcode Scanner 2027

Android app (WebView + Google ML Kit on-device barcode decoding). Package: `com.smartqr.barcodescanner2027`.
Built in the cloud by GitHub Actions (`.github/workflows/build.yml`). Privacy policy: `app/src/main/assets/www/privacy-policy.html`.
