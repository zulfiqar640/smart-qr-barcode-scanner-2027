/* QR Smart Scanner – Digital 2027 icon set.
   Every icon has its own symbol and colour identity: translucent glass halo + neon gradient stroke + solid accent.
   Usage: DIGI.svg("scan", 24) -> inline <svg> markup. Gradients live in one shared <defs> block. */
(function (w) {
  "use strict";
  var G = {
    blue: ["#5CD0FF", "#1F5BFF"], purple: ["#D79BFF", "#7A2CFF"], gold: ["#FFEE8A", "#FF9F0A"], teal: ["#7DF7E1", "#00AFA0"],
    cyan: ["#92F4FF", "#00B4E6"], pink: ["#FF9FD8", "#F0289B"], indigo: ["#8FA6FF", "#7A3CFF"], green: ["#A4FF92", "#12B24A"],
    rose: ["#FFA3C8", "#E8337E"], silver: ["#F1F6FF", "#7C97C2"], sky: ["#8ED8FF", "#2D8CFF"], coral: ["#FFA08C", "#F2455A"],
    orange: ["#FFD08A", "#FF6B1A"], amber: ["#FFE57A", "#FF8A00"], lime: ["#D2FF7C", "#45C400"], emerald: ["#76FFB6", "#00A86B"],
    mint: ["#B4FFD9", "#1FD1A0"], red: ["#FF9C8F", "#EE2F45"], iris: ["#A9B8FF", "#5B6CFF"], orchid: ["#F6AAFF", "#B23CFF"],
    aqua: ["#90FFEA", "#00C2A8"], ember: ["#FFBA7A", "#FF4E36"], slate: ["#C2CCE8", "#6677A8"]
  };
  var TEETH = "";
  for (var a = 0; a < 360; a += 45) TEETH += '<rect x="10.6" y="2.3" width="2.8" height="4.2" rx="1.1" transform="rotate(' + a + ' 12 12)"/>';
  var STAR = "M12 3.2l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.5l6-.8z";
  var SH = "M12 3l7.5 2.8v5.7c0 4.5-3.1 8-7.5 9.5-4.4-1.5-7.5-5-7.5-9.5V5.8z";
  var LENS = '<circle cx="10.5" cy="10.5" r="6.5"/>';
  var HAND = '<path d="M15.5 15.5l5 5"/>';
  var FL = '<path d="M7.6 3h8.8l-1.8 4.6H9.4z"/><path d="M9.4 7.6h5.2V19a2 2 0 0 1-2 2h-1.2a2 2 0 0 1-2-2z"/>';
  var QRC = "M3.5 8V5.5a2 2 0 0 1 2-2H8M16 3.5h2.5a2 2 0 0 1 2 2V8M20.5 16v2.5a2 2 0 0 1-2 2H16M8 20.5H5.5a2 2 0 0 1-2-2V16";
  /* name: [colour, halo(fill, translucent), stroke paths, solid accents] */
  var D = {
    menu: ["iris", "", '<path d="M4 7h16M4 12h10M4 17h16"/>', ""],
    back: ["sky", "", '<path d="M19.5 12H5M11 5.5 4.5 12l6.5 6.5"/>', ""],
    close: ["coral", '<circle cx="12" cy="12" r="9"/>', '<path d="M7.5 7.5l9 9M16.5 7.5l-9 9"/>', ""],
    more: ["iris", "", "", '<circle cx="12" cy="5.5" r="1.9"/><circle cx="12" cy="12" r="1.9"/><circle cx="12" cy="18.5" r="1.9"/>'],
    check: ["mint", '<circle cx="12" cy="12" r="9.5"/>', '<path d="M7 12.5l3.6 3.6L17.2 9"/>', ""],
    scan: ["blue", '<rect x="7.5" y="7.5" width="9" height="9" rx="2"/>', '<path d="' + QRC + '"/>', '<rect x="9" y="9" width="2.5" height="2.5" rx=".5"/><rect x="12.5" y="9" width="2.5" height="2.5" rx=".5"/><rect x="9" y="12.5" width="2.5" height="2.5" rx=".5"/><rect x="13" y="13" width="2" height="2" rx=".4"/>'],
    image: ["purple", '<rect x="3" y="4" width="18" height="12.5" rx="3"/>', '<rect x="3" y="4" width="18" height="12.5" rx="3"/><path d="M3 13.5l4.5-4.5 4 4 2.5-2.5 4.2 4.2"/>', '<circle cx="16.5" cy="8.3" r="1.6"/><rect x="2" y="19" width="20" height="2" rx="1"/>'],
    gallery: ["orchid", '<rect x="7" y="3.5" width="14" height="12" rx="2.5"/>', '<rect x="7" y="3.5" width="14" height="12" rx="2.5"/><path d="M17 20H6.5A2.5 2.5 0 0 1 4 17.5V8M7.5 14l3.5-3.5 2.5 2.5 2-2 4 3.5"/>', '<circle cx="11.7" cy="7.6" r="1.5"/>'],
    star: ["gold", "", '<path d="' + STAR + '"/>', '<path d="' + STAR + '"/>'],
    starO: ["gold", '<path d="' + STAR + '"/>', '<path d="' + STAR + '"/>', ""],
    history: ["teal", '<circle cx="12" cy="12" r="8.2"/>', '<path d="M3.8 12a8.2 8.2 0 1 0 2.5-5.9M3.5 4.2v4h4M12 7.6V12l3 1.8"/>', '<circle cx="12" cy="12" r="1.2"/>'],
    person: ["cyan", '<circle cx="12" cy="8.5" r="4"/>', '<circle cx="12" cy="8.5" r="4"/><path d="M4.5 20c.9-3.6 3.8-5.5 7.5-5.5s6.6 1.9 7.5 5.5"/>', ""],
    myqr: ["cyan", "", '<path d="' + QRC + '"/>', '<circle cx="12" cy="9.8" r="2.4"/><path d="M7.8 17c.5-2.3 2.2-3.4 4.2-3.4s3.7 1.1 4.2 3.4z"/>'],
    qrgen: ["pink", "", '<rect x="3.5" y="3.5" width="6.5" height="6.5" rx="1.5"/><rect x="14" y="3.5" width="6.5" height="6.5" rx="1.5"/><rect x="3.5" y="14" width="6.5" height="6.5" rx="1.5"/><path d="M17.2 14v6.5M14 17.2h6.5"/>', '<rect x="5.7" y="5.7" width="2.1" height="2.1" rx=".5"/><rect x="16.2" y="5.7" width="2.1" height="2.1" rx=".5"/><rect x="5.7" y="16.2" width="2.1" height="2.1" rx=".5"/>'],
    edit: ["orange", "", '<path d="M4 20l1-4.5L16.5 4a2.1 2.1 0 0 1 3 3L8 18.5zM14.5 6l3.5 3.5"/>', ""],
    gear: ["indigo", '<circle cx="12" cy="12" r="6.5"/>', '<circle cx="12" cy="12" r="6.3"/><circle cx="12" cy="12" r="2.6"/>', TEETH],
    flask: ["green", '<path d="M7.7 14.5h8.6l2.3 4a1.2 1.2 0 0 1-1 1.8H6.4a1.2 1.2 0 0 1-1-1.8z"/>', '<path d="M9.5 3.5h5M10.3 3.5v5.6L5 18.2a2 2 0 0 0 1.7 3h10.6a2 2 0 0 0 1.7-3l-5.3-9.1V3.5"/>', '<circle cx="10.5" cy="17.2" r="1"/><circle cx="14" cy="16" r=".8"/>'],
    share: ["rose", "", '<path d="M8.2 11l7.6-4M8.2 13l7.6 4"/>', '<circle cx="6" cy="12" r="2.8"/><circle cx="18" cy="6" r="2.8"/><circle cx="18" cy="18" r="2.8"/>'],
    lock: ["silver", '<path d="' + SH + '"/>', '<path d="' + SH + '"/><path d="M10 11v-1.2a2 2 0 0 1 4 0V11"/>', '<rect x="9.2" y="11" width="5.6" height="4.6" rx="1.1"/>'],
    camera: ["sky", '<rect x="4" y="6" width="16" height="13" rx="2.5"/>', '<path d="M4 8.5A2.5 2.5 0 0 1 6.5 6h1.2l1.3-2h6l1.3 2h1.2A2.5 2.5 0 0 1 20 8.5v8a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 16.5z"/><circle cx="12" cy="12.5" r="3.2"/>', '<circle cx="12" cy="12.5" r="1.1"/>'],
    flip: ["lime", "", '<path d="M4 12a8 8 0 0 1 13.7-5.6L20 8.5M20 4v4.5h-4.5M20 12a8 8 0 0 1-13.7 5.6L4 15.5M4 20v-4.5h4.5"/>', '<circle cx="12" cy="12" r="2.2"/>'],
    flashOn: ["amber", '<path d="M7.6 3h8.8l-1.8 4.6H9.4zM9.4 7.6h5.2V19a2 2 0 0 1-2 2h-1.2a2 2 0 0 1-2-2z"/>', FL + '<path d="M3 4.2l2.4 1.7M21 4.2l-2.4 1.7M2.6 9.3h2.6M18.8 9.3h2.6"/>', '<rect x="11.2" y="11" width="1.6" height="3.4" rx=".8"/>'],
    flashOff: ["slate", "", FL + '<path d="M3.5 3.5l17 17"/>', '<rect x="11.2" y="11" width="1.6" height="3.4" rx=".8"/>'],
    zoomIn: ["orange", LENS, LENS + HAND + '<path d="M10.5 7.8v5.4M7.8 10.5h5.4"/>', ""],
    zoomOut: ["orange", LENS, LENS + HAND + '<path d="M7.8 10.5h5.4"/>', ""],
    search: ["blue", LENS, LENS + HAND, '<circle cx="10.5" cy="10.5" r="2"/>'],
    web: ["sky", '<circle cx="11" cy="11" r="7.5"/>', '<circle cx="11" cy="11" r="7.5"/><path d="M3.5 11h15M11 3.5c2.2 2.2 3 4.7 3 7.5s-.8 5.3-3 7.5c-2.2-2.2-3-4.7-3-7.5s.8-5.3 3-7.5M16.5 16.5l4 4"/>', ""],
    copy: ["iris", '<rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2.5"/>', '<rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2.5"/><path d="M15.5 8.5V6A2.5 2.5 0 0 0 13 3.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5"/>', ""],
    save: ["emerald", '<path d="M5.5 3.5h10.7l3.3 3.3v11.7a2 2 0 0 1-2 2h-12a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2z"/>', '<path d="M5.5 3.5h10.7l3.3 3.3v11.7a2 2 0 0 1-2 2h-12a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2zM7.5 3.5v5h7v-5M7.5 20.5v-6h9v6"/>', '<rect x="11.5" y="4.6" width="2" height="2.8" rx=".5"/>'],
    download: ["lime", '<rect x="4" y="15.5" width="16" height="4.5" rx="2"/>', '<path d="M12 3.5v11M7.5 10.5l4.5 4.5 4.5-4.5M4 15.5v2A2.5 2.5 0 0 0 6.5 20h11a2.5 2.5 0 0 0 2.5-2.5v-2"/>', ""],
    del: ["red", '<path d="M6.5 6.5l.9 12.2a2 2 0 0 0 2 1.8h5.2a2 2 0 0 0 2-1.8l.9-12.2z"/>', '<path d="M4.5 6.5h15M9.5 6.5V4.5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2M6.5 6.5l.9 12.2a2 2 0 0 0 2 1.8h5.2a2 2 0 0 0 2-1.8l.9-12.2M10 10.5v6M14 10.5v6"/>', ""],
    barcode: ["ember", "", '<path d="M4 4.5v15M7.5 4.5v15M14.5 4.5v15M20 4.5v15"/>', '<rect x="9.8" y="4.5" width="2.4" height="15" rx=".6"/><rect x="16.2" y="4.5" width="1.6" height="15" rx=".5"/>'],
    filter: ["orchid", '<path d="M4 5.5h16l-6.2 7.3v5.4l-3.6 1.8v-7.2z"/>', '<path d="M4 5.5h16l-6.2 7.3v5.4l-3.6 1.8v-7.2z"/>', ""],
    file: ["aqua", '<path d="M6.5 3.5h7.5l4.5 4.5v11a1.5 1.5 0 0 1-1.5 1.5h-10.5A1.5 1.5 0 0 1 5 19V5a1.5 1.5 0 0 1 1.5-1.5z"/>', '<path d="M6.5 3.5h7.5l4.5 4.5v11a1.5 1.5 0 0 1-1.5 1.5h-10.5A1.5 1.5 0 0 1 5 19V5a1.5 1.5 0 0 1 1.5-1.5zM14 3.5V8h4.5M8.5 13h7M8.5 16.5h5"/>', ""],
    sound: ["sky", '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/>', '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4zM15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>', ""],
    vibrate: ["purple", '<rect x="8" y="3.5" width="8" height="17" rx="2"/>', '<rect x="8" y="3.5" width="8" height="17" rx="2"/><path d="M4.5 9v6M19.5 9v6M2 11v2M22 11v2"/>', '<rect x="10.5" y="17" width="3" height="1.2" rx=".6"/>'],
    layers: ["orchid", "", '<path d="M12 3.5l8.5 4.5-8.5 4.5L3.5 8zM3.5 12.5L12 17l8.5-4.5M3.5 16.5L12 21l8.5-4.5"/>', ""],
    repeat: ["aqua", "", '<path d="M4 11V9.5A3.5 3.5 0 0 1 7.5 6H19M16 3l3 3-3 3M20 13v1.5a3.5 3.5 0 0 1-3.5 3.5H5M8 21l-3-3 3-3"/>', ""],
    warn: ["amber", '<path d="M12 4l9 15.5H3z"/>', '<path d="M12 4l9 15.5H3zM12 10v4.3"/>', '<circle cx="12" cy="16.9" r="1.1"/>'],
    shieldOk: ["green", '<path d="' + SH + '"/>', '<path d="' + SH + '"/><path d="M8.6 12l2.4 2.5 4.4-5"/>', ""],
    shieldBad: ["red", '<path d="' + SH + '"/>', '<path d="' + SH + '"/><path d="M12 8.5v4"/>', '<circle cx="12" cy="15.6" r="1.1"/>'],
    cal: ["orange", '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/>', '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/>', '<rect x="7" y="13" width="3" height="3" rx=".8"/>'],
    clip: ["teal", '<rect x="5" y="4.5" width="14" height="16" rx="2.5"/>', '<rect x="5" y="4.5" width="14" height="16" rx="2.5"/><path d="M9 4.5V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v.5"/>', '<rect x="8.5" y="10" width="7" height="1.6" rx=".8"/><rect x="8.5" y="13.6" width="5" height="1.6" rx=".8"/>'],
    geo: ["coral", '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/>', '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/>', '<circle cx="12" cy="9.5" r="2.4"/>'],
    phone: ["green", '<path d="M6.5 4h3l1.5 4-2 1.3a11 11 0 0 0 5.7 5.7L16 13l4 1.5v3a2 2 0 0 1-2 2A14.5 14.5 0 0 1 4.5 6a2 2 0 0 1 2-2z"/>', '<path d="M6.5 4h3l1.5 4-2 1.3a11 11 0 0 0 5.7 5.7L16 13l4 1.5v3a2 2 0 0 1-2 2A14.5 14.5 0 0 1 4.5 6a2 2 0 0 1 2-2z"/>', ""],
    mail: ["sky", '<rect x="3.5" y="5.5" width="17" height="13" rx="3"/>', '<rect x="3.5" y="5.5" width="17" height="13" rx="3"/><path d="M4 7.5l8 6 8-6"/>', ""],
    sms: ["lime", '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 4v-4A2.5 2.5 0 0 1 4 13.5z"/>', '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 4v-4A2.5 2.5 0 0 1 4 13.5z"/>', '<circle cx="8.5" cy="9.3" r="1.1"/><circle cx="12" cy="9.3" r="1.1"/><circle cx="15.5" cy="9.3" r="1.1"/>'],
    wifi: ["aqua", "", '<path d="M3 9.5a13 13 0 0 1 18 0M6 13a8.5 8.5 0 0 1 12 0M9 16.4a4 4 0 0 1 6 0"/>', '<circle cx="12" cy="19.5" r="1.6"/>'],
    link: ["iris", "", '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 11 18.7l1-1"/>', ""],
    text: ["orchid", '<rect x="3.5" y="3.5" width="17" height="17" rx="3.5"/>', '<rect x="3.5" y="3.5" width="17" height="17" rx="3.5"/><path d="M8 8.5h8M12 8.5v8"/>', ""],
    install: ["emerald", '<rect x="6" y="2.5" width="12" height="19" rx="3"/>', '<rect x="6" y="2.5" width="12" height="19" rx="3"/><path d="M12 7v7M9 11.5l3 3 3-3"/>', ""]
  };
  var NS = "http://www.w3.org/2000/svg";
  function defs() {
    var s = '<svg xmlns="' + NS + '" width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>';
    for (var k in G) s += '<linearGradient id="g-' + k + '" gradientUnits="userSpaceOnUse" x1="2" y1="2" x2="22" y2="22"><stop offset="0" stop-color="' + G[k][0] + '"/><stop offset="1" stop-color="' + G[k][1] + '"/></linearGradient>';
    return s + "</defs></svg>";
  }
  function svg(n, size) {
    var d = D[n]; if (!d) return "";
    var f = "url(#g-" + d[0] + ")";
    return '<svg class="ic" viewBox="0 0 24 24" data-ic="' + n + '" style="--g:' + G[d[0]][1] + (size ? ";width:" + size + "px;height:" + size + "px" : "") + '" aria-hidden="true">' +
      (d[1] ? '<g fill="' + f + '" fill-opacity=".24" stroke="none">' + d[1] + "</g>" : "") +
      (d[2] ? '<g fill="none" stroke="' + f + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + d[2] + "</g>" : "") +
      (d[3] ? '<g fill="' + f + '" stroke="none">' + d[3] + "</g>" : "") + "</svg>";
  }
  function mount() { if (document.getElementById("digi-defs")) return; var t = document.createElement("div"); t.id = "digi-defs"; t.innerHTML = defs(); document.body.insertBefore(t, document.body.firstChild); }
  if (document.body) mount(); else document.addEventListener("DOMContentLoaded", mount);
  w.DIGI = { svg: svg, has: function (n) { return !!D[n]; }, names: Object.keys(D), colors: G };
})(window);
