/* Android app glue. Only active inside the native wrapper (window.AndroidBridge); does nothing in a normal browser. */
(function () {
  "use strict";
  var B = window.AndroidBridge; if (!B) return;
  window.IS_ANDROID_APP = true;
  /* Google ML Kit barcode engine exposed through the standard BarcodeDetector API, so the web code is unchanged */
  var ALL = ["aztec", "codabar", "code_39", "code_93", "code_128", "data_matrix", "ean_8", "ean_13", "itf", "pdf417", "qr_code", "upc_a", "upc_e"];
  var pending = new Map(), seq = 0;
  window.__mlResult = function (id, json) { var f = pending.get(id); if (f) { pending.delete(id); var l = []; try { l = JSON.parse(json); } catch (e) {} f(l); } };
  function box(b, k) { return b ? { x: b.x * k, y: b.y * k, width: b.width * k, height: b.height * k, top: b.y * k, left: b.x * k, right: (b.x + b.width) * k, bottom: (b.y + b.height) * k } : b; }
  window.BarcodeDetector = class {
    constructor(o) { this.f = o && o.formats && o.formats.length ? o.formats : null; }
    static async getSupportedFormats() { return ALL.slice(); }
    detect(src) {
      var self = this;
      return new Promise(function (res) {
        try {
          var w0 = src.videoWidth || src.naturalWidth || src.width, h0 = src.videoHeight || src.naturalHeight || src.height;
          if (!w0 || !h0) { res([]); return; }
          var k = Math.min(1, 960 / Math.max(w0, h0)), c = document.createElement("canvas");
          c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
          c.getContext("2d").drawImage(src, 0, 0, c.width, c.height);
          var b64 = c.toDataURL("image/jpeg", 0.75).split(",")[1], id = ++seq;
          var t = setTimeout(function () { pending.delete(id); res([]); }, 4000);
          pending.set(id, function (list) {
            clearTimeout(t);
            res(list.filter(function (x) { return !self.f || self.f.indexOf(x.format) >= 0; }).map(function (x) {
              return { rawValue: x.rawValue, format: x.format, boundingBox: box(x.boundingBox, 1 / k), cornerPoints: (x.cornerPoints || []).map(function (p) { return { x: p.x / k, y: p.y / k }; }) };
            }));
          });
          B.detect(id, b64);
        } catch (e) { res([]); }
      });
    }
  };
  /* links open in the phone's own apps (browser, dialer, SMS, mail, maps); internal pages stay in the app */
  window.open = function (u) { try { B.openExternal(new URL(u, location.href).href); } catch (e) {} return null; };
})();
