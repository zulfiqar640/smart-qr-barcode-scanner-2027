package com.smartqr.barcodescanner2027;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewAssetLoader;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

/**
 * Hosts the QR Smart Scanner web app (bundled in assets/www) inside a WebView.
 * The app is served from https://appassets.androidplatform.net (a secure origin, so the camera works),
 * and never needs the INTERNET permission.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";
    private static final List<String> EXTERNAL_SCHEMES =
            Arrays.asList("http", "https", "tel", "sms", "smsto", "mailto", "geo");

    private static final int RC_CAMERA = 10;
    private static final int RC_FILE = 11;
    private static final int RC_LOCATION = 12;

    private WebView web;
    private WebViewAssetLoader assetLoader;
    private BarcodeScanner scanner;

    private PermissionRequest pendingWebPermission;
    private ValueCallback<Uri[]> fileCallback;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#060F34"));
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Android 15 draws edge-to-edge: keep the web content clear of the system bars and keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        scanner = BarcodeScanning.getClient();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setGeolocationEnabled(true);

        web.setBackgroundColor(Color.parseColor("#060F34"));
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) {
                    return false; // our own pages stay in the app
                }
                route(u);
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsVideo = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            wantsVideo = true;
                        }
                    }
                    if (!wantsVideo) {
                        request.deny();
                        return;
                    }
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        if (pendingWebPermission != null) {
                            pendingWebPermission.deny();
                        }
                        pendingWebPermission = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, RC_CAMERA);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), RC_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    toast("No gallery or file app found");
                    return false;
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    geoOrigin = origin;
                    geoCallback = callback;
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, RC_LOCATION);
                }
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });

        web.loadUrl(START_URL);
    }

    /** Opens a link: our own pages inside the app, everything else in the matching Android app. */
    private void route(Uri u) {
        if (u == null) {
            return;
        }
        if (HOST.equals(u.getHost())) {
            web.loadUrl(u.toString());
            return;
        }
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        if (!EXTERNAL_SCHEMES.contains(scheme)) {
            return; // ignore javascript:, intent:, file:, blob: ...
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) {
            toast("No app can open this link");
        }
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == RC_CAMERA && pendingWebPermission != null) {
            if (granted) {
                pendingWebPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                pendingWebPermission.deny();
            }
            pendingWebPermission = null;
        } else if (requestCode == RC_LOCATION && geoCallback != null) {
            boolean any = false;
            for (int g : grantResults) {
                if (g == PackageManager.PERMISSION_GRANTED) {
                    any = true;
                }
            }
            geoCallback.invoke(geoOrigin, any, false);
            geoCallback = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (scanner != null) {
            scanner.close();
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------------------------------
    // JavaScript bridge (window.AndroidBridge). Only our own bundled pages are ever loaded here.
    // ------------------------------------------------------------------------------------------
    private class Bridge {

        @JavascriptInterface
        public void detect(final int id, String base64Jpeg) {
            try {
                byte[] bytes = Base64.decode(base64Jpeg, Base64.DEFAULT);
                final Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bmp == null) {
                    deliver(id, "[]");
                    return;
                }
                scanner.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener(list -> deliver(id, toJson(list)))
                        .addOnFailureListener(e -> deliver(id, "[]"));
            } catch (Exception e) {
                deliver(id, "[]");
            }
        }

        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String where;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) {
                        throw new Exception("insert failed");
                    }
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        out.write(data);
                    }
                    where = "Downloads";
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    File f = new File(dir, name);
                    try (OutputStream out = new FileOutputStream(f)) {
                        out.write(data);
                    }
                    where = f.getAbsolutePath();
                }
                toast("Saved to " + where + ": " + name);
            } catch (Exception e) {
                toast("Could not save the file");
            }
        }

        @JavascriptInterface
        public void shareFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new Exception("mkdir failed");
                }
                final File f = new File(dir, name);
                try (OutputStream out = new FileOutputStream(f)) {
                    out.write(data);
                }
                final String type = mime;
                runOnUiThread(() -> {
                    Uri uri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".fileprovider", f);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType(type);
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Share"));
                });
            } catch (Exception e) {
                toast("Could not share the file");
            }
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Share"));
            });
        }

        @JavascriptInterface
        public void shareApp() {
            share("Smart QR Scanner - fast, private QR & barcode scanner and creator: "
                    + "https://play.google.com/store/apps/details?id=" + getPackageName());
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("QR", text));
                }
            });
        }

        @JavascriptInterface
        public void openExternal(final String url) {
            runOnUiThread(() -> route(Uri.parse(url)));
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                startActivity(i);
            });
        }
    }

    private void deliver(final int id, final String json) {
        final String js = "window.__mlResult(" + id + "," + JSONObject.quote(json) + ")";
        runOnUiThread(() -> {
            if (web != null) {
                web.evaluateJavascript(js, null);
            }
        });
    }

    private static String formatName(int f) {
        switch (f) {
            case Barcode.FORMAT_QR_CODE: return "qr_code";
            case Barcode.FORMAT_AZTEC: return "aztec";
            case Barcode.FORMAT_CODABAR: return "codabar";
            case Barcode.FORMAT_CODE_39: return "code_39";
            case Barcode.FORMAT_CODE_93: return "code_93";
            case Barcode.FORMAT_CODE_128: return "code_128";
            case Barcode.FORMAT_DATA_MATRIX: return "data_matrix";
            case Barcode.FORMAT_EAN_8: return "ean_8";
            case Barcode.FORMAT_EAN_13: return "ean_13";
            case Barcode.FORMAT_ITF: return "itf";
            case Barcode.FORMAT_PDF417: return "pdf417";
            case Barcode.FORMAT_UPC_A: return "upc_a";
            case Barcode.FORMAT_UPC_E: return "upc_e";
            default: return "unknown";
        }
    }

    private static String toJson(List<Barcode> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Barcode b : list) {
                String raw = b.getRawValue();
                if (raw == null) {
                    raw = b.getDisplayValue();
                }
                if (raw == null || raw.trim().isEmpty()) {
                    continue;
                }
                JSONObject o = new JSONObject();
                o.put("rawValue", raw);
                o.put("format", formatName(b.getFormat()));
                Rect r = b.getBoundingBox();
                if (r != null) {
                    JSONObject bb = new JSONObject();
                    bb.put("x", r.left);
                    bb.put("y", r.top);
                    bb.put("width", r.width());
                    bb.put("height", r.height());
                    o.put("boundingBox", bb);
                }
                Point[] pts = b.getCornerPoints();
                if (pts != null) {
                    JSONArray pa = new JSONArray();
                    for (Point p : pts) {
                        JSONObject po = new JSONObject();
                        po.put("x", p.x);
                        po.put("y", p.y);
                        pa.put(po);
                    }
                    o.put("cornerPoints", pa);
                }
                arr.put(o);
            }
        } catch (Exception ignored) {
            // return what we have
        }
        return arr.toString();
    }
}
